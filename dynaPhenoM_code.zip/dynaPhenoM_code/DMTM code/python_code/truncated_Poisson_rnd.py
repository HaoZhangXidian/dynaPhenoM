import numpy as np


def truncated_Poisson_sample(poisson_rate):

    poisson_rate_1 = poisson_rate[np.where(poisson_rate>1)]
    poisson_rate_2 = poisson_rate[np.where(poisson_rate<=1)]

    x = np.zeros_like(poisson_rate)
    x_1 = np.zeros([poisson_rate_1.size])
    x_2 = np.zeros([poisson_rate_2.size])

    while True:
        sample_index = np.where(x_1 == 0)
        if sample_index[0].size == 0:
            break
        else:
            rate_1_remain = poisson_rate_1[sample_index]
            temp = np.random.poisson(rate_1_remain)
            index = temp > 0
            x_1[sample_index[0][index]] = temp[index]
    x[np.where(poisson_rate>1)] = x_1

    while True:
        sample_index = np.where(x_2 == 0)
        if sample_index[0].size == 0:
            break
        else:
            rate_2_remain = poisson_rate_2[sample_index]
            temp = 1 + np.random.poisson(rate_2_remain)
            index = np.random.rand(temp.size) < (1./temp)
            x_2[sample_index[0][index]] = temp[index]
    x[np.where(poisson_rate<=1)] = x_2

    return x

if __name__ =="__main__":

    input = np.random.rand(1000, 1000) + 1
    out = truncated_Poisson_sample(input)







